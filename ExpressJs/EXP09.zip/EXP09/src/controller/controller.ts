import { Request, Response } from 'express';
import { CourseService } from '../service/CourseService';

export class CourseController {
    constructor(private courseService: CourseService) { }

    async deleteCourse(req: Request, res: Response): Promise<void> {
        const { id } = req.params;

        if (!id || typeof id !== 'string') {
            res.status(400).json({ error: "Invalid Course ID" });
            return;
        }

        try {
            await this.courseService.deleteCourse(id);
            res.status(200).json({ message: "Course deleted successfully" });
        } catch (error: any) {
            res.status(400).json({ error: error.message });
        }
    }
}