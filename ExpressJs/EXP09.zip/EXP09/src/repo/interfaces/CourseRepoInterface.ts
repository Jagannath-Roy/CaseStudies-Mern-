import { Course } from "../../models/Course";

export interface CourseRepoInterface {
  findAll(): Promise<Course[]>;
  findById(id: string): Promise<Course | null>;
  save(course: Course): Promise<void>;
  delete(id: string): Promise<boolean>;
}