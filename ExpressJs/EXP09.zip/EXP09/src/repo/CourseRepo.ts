import { CourseRepoInterface } from './interfaces/CourseRepoInterface';
import { Course } from '../models/Course';

export class CourseRepo implements CourseRepoInterface {
    private courses: Course[] = [
        { id: "1", title: "Math" ,status: 'avilable'},
        { id: "2", title: "English", status: 'not-avilable'}
    ];

    async findAll(): Promise<Course[]> {
        return this.courses;
    }

    async findById(id: string): Promise<Course | null> {
        return this.courses.find(course => course.id === id) || null;
    }

    async save(book: Course): Promise<void> {
        const index = this.courses.findIndex(course => course.id === book.id);
        if (index !== -1) {
            this.courses[index] = book;
        } else {
            this.courses.push(book);
        }
    }

    async delete(id: string): Promise<boolean> {
        const index = this.courses.findIndex(course => course.id === id);
        if(index == -1) return false;
        this.courses.splice(index, 1);
        return true;
    }
}