import { CourseRepoInterface } from '../repo/interfaces/CourseRepoInterface';
import { Course } from '../models/Course';
import { error } from 'node:console';

export class CourseService {
    constructor(private courseRepository: CourseRepoInterface) { }

    async enrollCourse(courseId: string): Promise<void> {
        const course = await this.courseRepository.findById(courseId);

        if (!course) throw new Error('Course not found');
        if (course.status === 'not-avilable') throw new Error('Course already borrowed');
        /* Datsbase code */
    }

    async deleteCourse(courseId: string): Promise<void> {
        const isDeleted = await this.courseRepository.delete(courseId);
        if(!isDeleted) throw new Error('Course not found');
    }
}