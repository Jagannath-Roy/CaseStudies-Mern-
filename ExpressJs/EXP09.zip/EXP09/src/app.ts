/*
Implement a delete(courseId: string) method in the repository.

Add a service and route to allow admins to delete a course.
*/

import express from 'express';
import { CourseController } from './controller/controller';
import { CourseService } from './service/CourseService';
import { CourseRepo } from './repo/CourseRepo';

const app = express();
const port = 3000;

app.use(express.json());

const courseRepository = new CourseRepo();
const courseService = new CourseService(courseRepository);
const courseController = new CourseController(courseService);

app.delete('/courses/:id', (req, res) => courseController.deleteCourse(req, res));

app.listen(port, () => {
  console.log(`Running on http://localhost:${port}`);
});

