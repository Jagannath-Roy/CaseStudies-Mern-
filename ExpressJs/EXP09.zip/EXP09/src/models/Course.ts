export interface Course {
  id: string,
  title: string,
  status: 'avilable' | 'not-avilable'
}