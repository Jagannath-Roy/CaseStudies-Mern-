export interface Book {
  id: string;
  title: string;
  isBorrowed: boolean;
}