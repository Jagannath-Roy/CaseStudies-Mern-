import { Request, Response } from 'express';
import { BookService } from '../service/BookService';

export class BookController {
    constructor(private bookService: BookService) { }

    async borrowBook(req: Request, res: Response): Promise<void> {
        try {
            const { id } = req.params;

            if (typeof id !== 'string') {
                res.status(400).json({ error: "Invalid Book ID" });
                return;
            }

            const book = await this.bookService.borrowBook(id);
            res.json({ message: "Borrow successful", book });

        } catch (error: any) {
            res.status(400).json({ error: error.message });
        }
    }

    async returnBook(req: Request, res: Response): Promise<void> {
        try {
            const { id } = req.params;

            if (typeof id !== 'string') {
                res.status(400).json({ error: "Invalid Book ID" });
                return;
            }

            const book = await this.bookService.returnBook(id);
            res.json({ message: "Return successful", book });

        } catch (error: any) {
            res.status(400).json({ error: error.message });
        }
    }
}