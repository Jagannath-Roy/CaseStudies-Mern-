import { BookRepoInterface } from './interfaces/BookRepoInterface';
import { Book } from '../models/Book';

export class BookRepo implements BookRepoInterface {
    private books: Book[] = [
        { id: "1", title: "Math", isBorrowed: false },
        { id: "2", title: "English", isBorrowed: true }
    ];

    async findAll(): Promise<Book[]> {
        return this.books;
    }

    async findById(id: string): Promise<Book | null> {
        return this.books.find(book => book.id === id) || null;
    }

    async save(book: Book): Promise<void> {
        const index = this.books.findIndex(b => b.id === book.id);
        if (index !== -1) {
            this.books[index] = book;
        } else {
            this.books.push(book);
        }
    }
}