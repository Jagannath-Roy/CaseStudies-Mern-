import { Book } from "../../models/Book";

export interface BookRepoInterface {
  findAll(): Promise<Book[]>;
  findById(id: string): Promise<Book | null>;
  save(book: Book): Promise<void>;
}