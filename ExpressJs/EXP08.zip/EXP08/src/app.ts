/*
Add a returnBook method to BookService and BookController.

Ensure the repository updates the book’s status when returned.
*/

import express from 'express';
import { BookController } from './controller/controller';
import { BookService } from './service/BookService';
import { BookRepo } from './repo/BookRepo';

const app = express();
const port = 3000;

app.use(express.json());

const bookRepository = new BookRepo();

const bookService = new BookService(bookRepository);

const bookController = new BookController(bookService);

app.post('/books/:id/borrow', (req, res) => bookController.borrowBook(req, res));
app.post('/books/:id/return', (req, res) => bookController.returnBook(req, res));

app.listen(port, () => {
  console.log(`Running on http://localhost:${port}`);
});

