// test/test.ts
import "reflect-metadata";
import { Container } from "typedi";
import { AppointmentService } from "../AppointmentService";
import { BillingServiceToken } from "../interfaces/BillingInterface";

class MockBillingService {
  async charge(patientName: string, amount: number) {
    console.log(`[TEST-MOCK] Fake charge of $${amount} recorded for ${patientName}`);
  }
}

Container.set(BillingServiceToken, new MockBillingService());

const apptSystem = Container.get(AppointmentService);
apptSystem.book("Titli Biswas");
