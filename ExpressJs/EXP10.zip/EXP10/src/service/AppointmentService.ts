// services/AppointmentService.ts
import { Service, Inject } from "typedi";
import { BillingServiceToken } from "./interfaces/BillingInterface";
import type { BillingInterface } from "./interfaces/BillingInterface";

@Service()
export class AppointmentService {
  constructor(
    @Inject(BillingServiceToken) private billingService: BillingInterface
  ) {}

  async book(patientName: string) {
    console.log(`Booking appointment for ${patientName}...`);
    
    await this.billingService.charge(patientName, 50);
    
    console.log("Appointment confirmed.");
  }
}