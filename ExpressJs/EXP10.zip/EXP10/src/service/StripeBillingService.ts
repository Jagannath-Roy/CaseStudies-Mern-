import { Service } from "typedi";
import { BillingInterface , BillingServiceToken } from "./interfaces/BillingInterface";

@Service(BillingServiceToken)
export class StripeBillingService implements BillingInterface {
  async charge(patientName: string, amount: number) {
    console.log(`[Stripe] Charging $${amount} to card for: ${patientName}`);
  }
}