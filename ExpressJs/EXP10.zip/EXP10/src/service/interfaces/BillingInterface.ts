import { Token } from "typedi";

export interface BillingInterface {
  charge(patientName: string, amount: number): Promise<void>;
}

export const BillingServiceToken = new Token<BillingInterface>("BILLING_SERVICE");