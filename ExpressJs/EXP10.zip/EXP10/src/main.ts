/*
Add a BillingService interface and a StripeBillingService implementation.

Inject BillingService into AppointmentService to charge patients when booking.

Write a test using a mock billing service to verify the charge is made.
*/
import "reflect-metadata";
import { Container } from "typedi";

import { AppointmentService } from "./service/AppointmentService";

const appointmentSystem = Container.get(AppointmentService);

appointmentSystem.book("Titli Biswas");