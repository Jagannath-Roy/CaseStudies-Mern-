import React from 'react';
import { useNotificationStore } from './stores/stores';
import type { NotificationType } from './stores/stores';

export const NotificationList: React.FC = () => {
  // Select state and actions
  const notifications = useNotificationStore((state) => state.notifications);
  const markAsRead = useNotificationStore((state) => state.markAsRead);
  const clearNotifications = useNotificationStore((state) => state.clearNotifications);

  // Helper to color-code messages based on type
  const getColor = (type: NotificationType) => {
    switch (type) {
      case 'error': return 'red';
      case 'success': return 'green';
      default: return 'blue';
    }
  };

  return (
    <div style={{ border: '1px solid #ddd', padding: '20px', maxWidth: '400px' }}>
      <h3>Notifications ({notifications.filter(n => !n.read).length} unread)</h3>
      
      {notifications.length === 0 ? (
        <p>No new notifications.</p>
      ) : (
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {notifications.map((note) => (
            <li 
              key={note.id} 
              style={{ 
                marginBottom: '10px', 
                padding: '10px', 
                border: '1px solid #eee',
                opacity: note.read ? 0.5 : 1, // Dim if read
                backgroundColor: note.read ? '#f9f9f9' : '#fff'
              }}
            >
              <strong style={{ color: getColor(note.type) }}>
                [{note.type.toUpperCase()}]
              </strong> 
              {' ' + note.message}
              
              {!note.read && (
                <button 
                  onClick={() => markAsRead(note.id)}
                  style={{ marginLeft: '10px', cursor: 'pointer' }}
                >
                  Mark Read
                </button>
              )}
            </li>
          ))}
        </ul>
      )}

      {notifications.length > 0 && (
        <button onClick={clearNotifications}>Clear All</button>
      )}
    </div>
  );
};