import React from 'react';
import { useNotificationStore } from './stores/stores';
import { NotificationList } from './NotificationList';

const App: React.FC = () => {
  const addNotification = useNotificationStore((state) => state.addNotification);

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h1>TaskFlow Dashboard</h1>
      
      {/* Control Panel to Simulate Events */}
      <div style={{ marginBottom: '20px' }}>
        <button onClick={() => addNotification('Project saved successfully', 'success')}>
          Add Success
        </button>
        <button onClick={() => addNotification('Failed to connect to server', 'error')}>
          Add Error
        </button>
        <button onClick={() => addNotification('New comment on your task', 'info')}>
          Add Info
        </button>
      </div>

      <hr />

      {/* The Notification Component */}
      <NotificationList />
    </div>
  );
};

export default App;