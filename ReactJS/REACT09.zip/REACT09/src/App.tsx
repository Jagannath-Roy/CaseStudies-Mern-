import React, { useState, Suspense, lazy } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import ErrorBoundary from './ErrorBoundary';

// 1. Lazy Load the components
// React won't import these files until we ask for them.
const AdminPanel = lazy(() => import('./AdminPanel'));
const ProfileSettings = lazy(() => import('./ProfileSettings'));

// A simple reusable loading spinner
const LoadingSpinner = () => <div style={{ color: 'gray' }}>🌀 Loading...</div>;

const Home = () => <h2>🏠 Home Dashboard</h2>;

const App: React.FC = () => {
  const [showSettings, setShowSettings] = useState(false);

  return (
    <Router>
      <div style={{ fontFamily: 'sans-serif', padding: '20px' }}>
        <nav style={{ marginBottom: '20px' }}>
          <Link to="/" style={{ marginRight: '10px' }}>Home</Link>
          <Link to="/admin">Admin (Lazy Route)</Link>
        </nav>

        {/* WRAPPER: ErrorBoundary catches network failures.
          WRAPPER: Suspense shows the fallback while code downloads.
        */}
        <ErrorBoundary>
          <Suspense fallback={<LoadingSpinner />}>
            
            <Routes>
              <Route path="/" element={
                <div>
                  <Home />
                  
                  {/* Component-Based Lazy Loading */}
                  <hr />
                  <p>Want to edit your profile?</p>
                  <button onClick={() => setShowSettings(true)}>
                    {showSettings ? 'Hide Settings' : 'Show Settings (Lazy Load)'}
                  </button>

                  {/* Settings only loads if 'showSettings' is true */}
                  {showSettings && (
                    <div style={{ marginTop: '20px' }}>
                      <Suspense fallback={<div>⚙️ Loading Settings UI...</div>}>
                        <ProfileSettings />
                      </Suspense>
                    </div>
                  )}
                </div>
              } />

              {/* Route-Based Lazy Loading */}
              <Route path="/admin" element={<AdminPanel />} />
            </Routes>
            
          </Suspense>
        </ErrorBoundary>
      </div>
    </Router>
  );
};

export default App;