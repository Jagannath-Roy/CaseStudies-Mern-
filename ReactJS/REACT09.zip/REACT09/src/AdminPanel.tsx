import React from 'react';

const AdminPanel = () => {
  return (
    <div style={{ padding: '20px', background: '#ffebee', border: '2px solid red' }}>
      <h2>🔒 Secret Admin Panel</h2>
      <p>This component was loaded lazily! Regular users never download this code.</p>
    </div>
  );
};

export default AdminPanel;