import React, { Component,type ErrorInfo,type ReactNode } from 'react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
}

class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false
  };

  public static getDerivedStateFromError(_: Error): State {
    return { hasError: true };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Lazy loading failed:", error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      return (
        <div style={{ padding: '20px', color: 'red', border: '1px dashed red' }}>
          <h3>⚠️ Something went wrong.</h3>
          <p>We couldn't load this section. Please check your connection and refresh.</p>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;