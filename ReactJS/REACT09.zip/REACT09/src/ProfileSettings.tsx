import React from 'react';

const ProfileSettings = () => {
  return (
    <div style={{ padding: '20px', background: '#e3f2fd', border: '2px solid blue', marginTop: '10px' }}>
      <h3>⚙️ Profile Settings</h3>
      <label>
        Username: <input type="text" defaultValue="Student123" />
      </label>
      <br />
      <button>Save Changes</button>
    </div>
  );
};

export default ProfileSettings;