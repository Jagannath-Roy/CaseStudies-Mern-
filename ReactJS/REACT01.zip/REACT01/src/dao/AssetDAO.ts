import { AssetInterface } from "../model/AssetInterface";

export let Asset : AssetInterface[] = [
    {name: "Google", symbol: "G", value: 10, change: 5},
    {name: "Tesla", symbol: "T", value: 10, change: 5},
    {name: "Samsung", symbol: "S", value: 10, change: 5},
    {name: "Titan", symbol: "T", value: 10, change: 5}
];