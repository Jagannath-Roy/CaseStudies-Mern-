import { AssetInterface } from "./model/AssetInterface";


interface PortfolioSummaryInterface {
    data: AssetInterface[]
}

export const PortfolioSummary = (props: PortfolioSummaryInterface) => {
    const totalValue = props.data.reduce((sum, item) => sum + item.value, 0);
    const totalChange = props.data.reduce((sum, item) => sum + item.change, 0);
    const avgChange = totalChange / props.data.length;

/*
    let sum = 0;
    props.data.forEach(item => {
        sum = item.value + sum;
    });
*/
    return (
        <div>
            <h3>Portfolio Summary </h3>
            <p> Total Value: { totalValue } </p>
            <p> Average Change: { avgChange } </p>
        </div>
    );
};