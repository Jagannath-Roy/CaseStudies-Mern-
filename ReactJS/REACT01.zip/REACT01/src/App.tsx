/**
Create a PortfolioSummary functional component that:

    Receives a typed array of assets (Asset[]) as props.

    Renders the total value and average percentage change.

Create an AssetEditor class component that:

    Has typed state for name, symbol, value, and change.

    Accepts a callback prop onUpdate (typed) to update an asset.

    Resets the form after submission.
*/
import {Asset} from './dao/AssetDAO';
import { PortfolioSummary } from "./PortfolioSummary";

export const App = () => {
  return(
    <div>
      {
        Asset.map((item,index) => (
          <div key = {index}> 
            <h1>{item.name}</h1>
            <h2>{item.symbol}</h2>
            <h2>{item.value}</h2>
            <h2>{item.change}</h2>
          </div>
        ))
      }
      <PortfolioSummary data={Asset}/>
    </div>
  );
};