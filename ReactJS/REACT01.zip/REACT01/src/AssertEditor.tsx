import React, { Component } from "react";
import { AssetInterface } from "./model/AssetInterface";

interface EditorProps {
  onUpdate: (asset: AssetInterface) => void; 
}

interface EditorState {
  name: string;
  symbol: string;
  value: string;
  change: string;
}

// 1. Configuration Array: Define your fields here
const FORM_FIELDS = [
  { name: "name", placeholder: "Name", type: "text" },
  { name: "symbol", placeholder: "Symbol", type: "text" },
  { name: "value", placeholder: "Value", type: "number" },
  { name: "change", placeholder: "Change %", type: "number" }
];

export class AssetEditor extends Component<EditorProps, EditorState> {
  state: EditorState = {
    name: "",
    symbol: "",
    value: "",
    change: ""
  };

  handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ [e.target.name]: e.target.value } as any);
  };

  handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    this.props.onUpdate({
      name: this.state.name,
      symbol: this.state.symbol,
      value: Number(this.state.value),
      change: Number(this.state.change)
    });
    this.setState({ name: "", symbol: "", value: "", change: "" });
  };

  render() {
    return (
      <form onSubmit={this.handleSubmit}>
        <h3>Add Asset</h3>
        
        {/* 2. Use .map() to generate inputs */}
        {FORM_FIELDS.map((field) => (
          <div key={field.name}>
            <input 
              name={field.name}
              type={field.type}
              placeholder={field.placeholder}
              // We cast field.name to ensure TS knows it matches a State key
              value={this.state[field.name as keyof EditorState]} 
              onChange={this.handleChange} 
            />
          </div>
        ))}

        <button type="submit">Add Asset</button>
      </form>
    );
  }
}