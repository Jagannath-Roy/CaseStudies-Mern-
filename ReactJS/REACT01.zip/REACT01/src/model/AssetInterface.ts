export interface AssetInterface{
    name: string,
    symbol: string, 
    value: number,
    change: number
}