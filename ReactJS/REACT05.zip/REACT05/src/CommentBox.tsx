import React, { useState } from 'react';

interface CommentBoxProps {
  onPost: (comment: string) => void;
}

export const CommentBox: React.FC<CommentBoxProps> = ({ onPost }) => {
  const [comment, setComment] = useState('');

  const handleSubmit = () => {
    if (!comment.trim()) return; 
    onPost(comment);
    setComment('');
  };

  return (
    <div>
      <input
        placeholder="Write a comment..."
        value={comment}
        onChange={(e) => setComment(e.target.value)}
        aria-label="comment-input"
      />
      <button onClick={handleSubmit}>Post</button>
    </div>
  );
};