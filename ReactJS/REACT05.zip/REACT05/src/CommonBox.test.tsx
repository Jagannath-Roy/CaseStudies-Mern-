import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import { CommentBox } from './CommentBox';

describe('CommentBox Component', () => {
  test('allows user to type, submit, and clears input', () => {

    const mockOnPost = jest.fn();
    
    render(<CommentBox onPost={mockOnPost} />);

    const input = screen.getByLabelText('comment-input');
    const button = screen.getByText('Post');

    fireEvent.change(input, { target: { value: 'Great article!' } });
    
    expect(input).toHaveValue('Great article!');

    fireEvent.click(button);

    expect(mockOnPost).toHaveBeenCalledTimes(1);
    expect(mockOnPost).toHaveBeenCalledWith('Great article!');

    expect(input).toHaveValue('');
  });
});