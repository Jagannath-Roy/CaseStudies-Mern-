import React from 'react';
import { useParams } from 'react-router-dom';
import type { DoctorPatientRouteParams } from './types/types';

export const DoctorPatientDetails: React.FC = () => {
  const { doctorId, patientId } = useParams<DoctorPatientRouteParams>();

  if (!doctorId || !patientId) {
    return <div>Error: Missing parameters.</div>;
  }

  const doctorIdNum = Number(doctorId);
  const patientIdNum = Number(patientId);

  if (isNaN(doctorIdNum) || isNaN(patientIdNum)) {
    return (
      <div>
        <h3>Error: Invalid ID format</h3>
        <p>Doctor ID and Patient ID must be numbers.</p>
        <p>Received: Doctor({doctorId}), Patient({patientId})</p>
      </div>
    );
  }

  return (
    <div>
      <h2>Consultation Details</h2>
      <ul>
        <li>Doctor ID: {doctorIdNum}</li>
        <li>Patient ID: {patientIdNum}</li>
        <li>Status: Active</li>
      </ul>
    </div>
  );
};