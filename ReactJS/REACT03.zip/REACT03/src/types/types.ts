export type DoctorPatientRouteParams = {
  doctorId: string;
  patientId: string;
};