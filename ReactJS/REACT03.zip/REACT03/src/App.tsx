import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import { DoctorList } from './DoctorList';
import { DoctorPatientDetails } from './DoctorPatient';

const App: React.FC = () => {
  return (
    <BrowserRouter>
      <nav>
        <Link to="/">Home (Doctor List)</Link>
      </nav>
      <hr />
      
      <Routes>
        <Route path="/" element={<DoctorList />} />
        
        {/* Define the dynamic route with two parameters */}
        <Route 
          path="/doctors/:doctorId/patients/:patientId" 
          element={<DoctorPatientDetails />} 
        />
      </Routes>
    </BrowserRouter>
  );
};

export default App;