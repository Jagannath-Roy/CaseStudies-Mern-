import React from 'react';
import { Link } from 'react-router-dom';

export const DoctorList: React.FC = () => {
  const doctors = [
    { id: 101, name: "Dr. Smith" },
    { id: 102, name: "Dr. Jones" }
  ];

  return (
    <div>
      <h2>Doctor Directory</h2>
      <ul>
        {doctors.map((doc) => (
          <li key={doc.id}>
            <h3>{doc.name} (ID: {doc.id})</h3>
            <ul>
              <li>
                <Link to={`/doctors/${doc.id}/patients/500`}>
                  View Patient 500
                </Link>
              </li>
              <li>
                <Link to={`/doctors/${doc.id}/patients/501`}>
                  View Patient 501
                </Link>
              </li>
              <li>
                <Link to={`/doctors/${doc.id}/patients/abc`}>
                  Test Invalid ID (abc)
                </Link>
              </li>
            </ul>
          </li>
        ))}
      </ul>
    </div>
  );
};