import React, { useState } from 'react';

interface TagInputProps {
  onAddTag: (tag: string) => void;
}

export const TagInput = React.memo(({ onAddTag }: TagInputProps) => {
  console.log('Rendering TagInput...');
  const [input, setInput] = useState('');

  const handleAdd = () => {
    if (input.trim()) {
      onAddTag(input);
      setInput('');
    }
  };

  return (
    <div style={{ border: '1px solid #eee', padding: '10px' }}>
      <input 
        value={input} 
        onChange={(e) => setInput(e.target.value)} 
        placeholder="New tag..." 
      />
      <button onClick={handleAdd}>Add Tag</button>
    </div>
  );
});

TagInput.displayName = 'TagInput';