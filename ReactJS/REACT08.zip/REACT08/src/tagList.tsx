import React, { useMemo } from 'react';

interface TagListProps {
  tags: string[];
  filter: string;
}


export const TagList = React.memo(({ tags, filter }: TagListProps) => {
  console.log('Rendering TagList...'); 

  const filteredTags = useMemo(() => {
    console.log('Computing filtered tags...');
    return tags.filter((tag) => tag.toLowerCase().includes(filter.toLowerCase()));
  }, [tags, filter]);

  return (
    <div style={{ border: '1px solid #ccc', padding: '10px', marginTop: '10px' }}>
      <h3>Tag List</h3>
      <ul>
        {filteredTags.map((tag, index) => (
          <li key={index}>{tag}</li>
        ))}
      </ul>
    </div>
  );
});

TagList.displayName = 'TagList';