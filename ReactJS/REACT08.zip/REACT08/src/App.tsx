import React, { useState, useCallback } from 'react';
import { TagList } from './tagList';
import { TagInput } from './TagInput';

const App: React.FC = () => {
  const [tags, setTags] = useState(['React', 'TypeScript', 'Memoization']);
  const [filter, setFilter] = useState('');

  const [counter, setCounter] = useState(0);

 
  const handleAddTag = useCallback((newTag: string) => {
    setTags((prevTags) => [...prevTags, newTag]);
  }, []);

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h1>Optimization Dashboard</h1>
      
      <div style={{ background: '#f0f0f0', padding: '10px', marginBottom: '20px' }}>
        <p>Unrelated Counter: {counter}</p>
        <button onClick={() => setCounter(c => c + 1)}>Increment Counter</button>
        <small> (Clicking this re-renders App, but should NOT re-render components below)</small>
      </div>

      <div style={{ marginBottom: '10px' }}>
        <label>Filter: </label>
        <input 
          value={filter} 
          onChange={(e) => setFilter(e.target.value)} 
        />
      </div>

      <TagInput onAddTag={handleAddTag} />
      <TagList tags={tags} filter={filter} />
    </div>
  );
};

export default App;