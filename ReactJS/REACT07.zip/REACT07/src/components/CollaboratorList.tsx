import React, { useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useCollaboratorStore } from '../stores/CollaboratorStore';

const fetchCollaboratorsAPI = async () => {
  await new Promise(resolve => setTimeout(resolve, 1000));
  return [
    { id: '1', name: 'Alice' },
    { id: '2', name: 'Bob' },
    { id: '3', name: 'Charlie' }
  ];
};

export const CollaboratorList: React.FC = () => {
  const { data, isLoading, error } = useQuery({
    queryKey: ['collaborators'],
    queryFn: fetchCollaboratorsAPI,
  });

  const setCollaborators = useCollaboratorStore((s) => s.setCollaborators);
  const collaborators = useCollaboratorStore((s) => s.collaborators);

  useEffect(() => {
    if (data) {
      setCollaborators(data);
    }
  }, [data, setCollaborators]);

  if (isLoading) return <div>Loading collaborators...</div>;
  if (error) return <div>Error loading data</div>;

  return (
    <div style={{ border: '1px solid #ccc', padding: '10px', marginTop: '20px' }}>
      <h3>Collaborators (Synced from API)</h3>
      <ul>
        {collaborators.map((c) => (
          <li key={c.id}>{c.name}</li>
        ))}
      </ul>
    </div>
  );
};