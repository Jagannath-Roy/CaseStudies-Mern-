import { create } from 'zustand';
import { devtools } from 'zustand/middleware';
import { immer } from 'zustand/middleware/immer';

interface HistoryEntry {
  noteId: string;
  action: string;
  timestamp: number;
}

interface HistoryState {
  logs: HistoryEntry[];
  addHistoryEntry: (noteId: string, action: string) => void;
  clearHistory: () => void;
}

export const useHistoryStore = create<HistoryState>()(
  devtools(
    immer((set) => ({
      logs: [],

      addHistoryEntry: (noteId, action) =>
        set((state) => {
          state.logs.push({
            noteId,
            action,
            timestamp: Date.now(),
          });
        }),

      clearHistory: () =>
        set((state) => {
          state.logs = [];
        }),
    })),
    { name: 'HistoryStore' } 
  )
);