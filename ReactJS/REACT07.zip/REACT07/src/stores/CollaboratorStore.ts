import { create } from 'zustand';

interface Collaborator {
  id: string;
  name: string;
}

interface CollaboratorStore {
  collaborators: Collaborator[];
  setCollaborators: (list: Collaborator[]) => void;
}

export const useCollaboratorStore = create<CollaboratorStore>((set) => ({
  collaborators: [],
  setCollaborators: (list) => set({ collaborators: list }),
}));