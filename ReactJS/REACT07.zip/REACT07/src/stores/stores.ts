import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

interface SessionState {
  userId: string | null;
  token: string | null;
  expiresAt: number | null; 
  role: 'admin' | 'user';  
  login: (id: string, token: string, role: 'admin' | 'user') => void;
}

export const useSessionStore = create<SessionState>()(
  persist(
    (set) => ({
      userId: null,
      token: null,
      expiresAt: null,
      role: 'user',

      login: (userId, token, role) => 
        set({ 
          userId, 
          token, 
          role, 
          expiresAt: Date.now() + 3600000 
        }),
    }),
    {
      name: 'collab-session', 
      storage: createJSONStorage(() => localStorage),
      
      partialize: (state) => ({ 
        userId: state.userId, 
        token: state.token, 
        role: state.role 
      }),

      version: 2,
      migrate: (persistedState: any, version) => {
        if (version < 2) {
          return { ...persistedState, role: 'user' };
        }
        return persistedState;
      },
    }
  )
);