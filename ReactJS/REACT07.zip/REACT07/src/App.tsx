import React from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useSessionStore } from './stores/stores';
import { useHistoryStore } from './stores/historyStores';
import { CollaboratorList } from './components/CollaboratorList';

const queryClient = new QueryClient();

const App: React.FC = () => {
  const { userId, role, login } = useSessionStore();
  const { logs, addHistoryEntry } = useHistoryStore();

  const handleSimulatedAction = () => {
    login('user_123', 'xyz_token', 'admin');
    addHistoryEntry('note_1', 'LOGIN_EVENT');
  };

  return (
    <QueryClientProvider client={queryClient}>
      <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
        <h1>CollabNotes Dashboard</h1>
        
        {/* Session Section */}
        <section style={{ marginBottom: '20px' }}>
          <h2>Session (Persisted)</h2>
          <p>User: {userId || 'Guest'}</p>
          <p>Role: {role}</p>
          <button onClick={handleSimulatedAction}>Simulate Login & Log Event</button>
        </section>

        {/* History Section */}
        <section style={{ marginBottom: '20px' }}>
          <h2>History Log (Devtools + Immer)</h2>
          <ul>
            {logs.map((log, i) => (
              <li key={i}>{log.action} on {log.noteId}</li>
            ))}
          </ul>
        </section>

        {/* Async Section */}
        <CollaboratorList />
        
      </div>
    </QueryClientProvider>
  );
};

export default App;