export type Currency = 'USD' | 'EUR' | 'GBP';
export type TransactionType = 'income' | 'expense';

export interface Transaction {
  id: string;
  amount: number;
  type: TransactionType;
  currency: Currency;
}

export interface BudgetState {
  transactions: Transaction[];
  displayCurrency: Currency;
}

export type BudgetAction =
  | { type: 'ADD'; payload: Transaction }
  | { type: 'REMOVE'; payload: string }
  | { type: 'SET_CURRENCY'; payload: Currency };