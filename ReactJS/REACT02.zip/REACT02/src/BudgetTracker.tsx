import React, { useReducer, useState } from 'react';
import type { Currency, TransactionType, Transaction, BudgetState, BudgetAction } from './types/types';

// Props definition
interface BudgetTrackerProps {
  rates: Record<Currency, number>;
}

const initialState: BudgetState = {
  transactions: [],
  displayCurrency: 'USD'
};

function budgetReducer(state: BudgetState, action: BudgetAction): BudgetState {
  switch (action.type) {
    case 'ADD':
      return { ...state, transactions: [...state.transactions, action.payload] };
    case 'REMOVE':
      return { ...state, transactions: state.transactions.filter(t => t.id !== action.payload) };
    case 'SET_CURRENCY':
      return { ...state, displayCurrency: action.payload };
    default:
      return state;
  }
}

export const BudgetTracker: React.FC<BudgetTrackerProps> = ({ rates }) => {
  const [state, dispatch] = useReducer(budgetReducer, initialState);
  
  // Local form state
  const [amount, setAmount] = useState<string>('');
  const [currency, setCurrency] = useState<Currency>('USD');
  const [type, setType] = useState<TransactionType>('income');

  // Logic to convert currency
  const convert = (amt: number, from: Currency, to: Currency) => {
    if (from === to) return amt;
    const amountInUSD = amt / rates[from];
    return amountInUSD * rates[to];
  };

  // Calculate total balance
  const totalBalance = state.transactions.reduce((acc, tx) => {
    const convertedAmt = convert(tx.amount, tx.currency, state.displayCurrency);
    return tx.type === 'income' ? acc + convertedAmt : acc - convertedAmt;
  }, 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newTx: Transaction = {
      id: Math.random().toString(),
      amount: Number(amount),
      currency,
      type
    };
    dispatch({ type: 'ADD', payload: newTx });
    setAmount('');
  };

  return (
    <div>
      <h2>Budget Tracker</h2>

      <div>
        <label>Display Currency: </label>
        <select 
          value={state.displayCurrency} 
          onChange={(e) => dispatch({ type: 'SET_CURRENCY', payload: e.target.value as Currency })}
        >
          <option value="USD">USD</option>
          <option value="EUR">EUR</option>
          <option value="GBP">GBP</option>
        </select>
        <h3>Net Balance: {totalBalance.toFixed(2)} {state.displayCurrency}</h3>
      </div>

      <form onSubmit={handleSubmit}>
        <input 
          type="number" 
          value={amount} 
          onChange={(e) => setAmount(e.target.value)} 
          placeholder="Amount" 
        />
        <select value={currency} onChange={(e) => setCurrency(e.target.value as Currency)}>
          <option value="USD">USD</option>
          <option value="EUR">EUR</option>
          <option value="GBP">GBP</option>
        </select>
        <select value={type} onChange={(e) => setType(e.target.value as TransactionType)}>
          <option value="income">Income</option>
          <option value="expense">Expense</option>
        </select>
        <button type="submit">Add Transaction</button>
      </form>

      <ul>
        {state.transactions.map(tx => (
          <li key={tx.id}>
            {tx.type.toUpperCase()}: {tx.amount} {tx.currency}
            <button onClick={() => dispatch({ type: 'REMOVE', payload: tx.id })}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};