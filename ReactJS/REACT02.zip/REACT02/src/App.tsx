import React from 'react';
import { BudgetTracker } from './BudgetTracker';

const App = () => {
  // Exchange rates relative to 1 USD
  const rates = {
    USD: 1,
    EUR: 0.92,
    GBP: 0.79
  };

  return (
    <div>
      <BudgetTracker rates={rates} />
    </div>
  );
};

export default App;