import React from 'react';
import { useStore } from './store/useStore';
import { NotificationsPanel } from './components/NotificationPanel';

const App: React.FC = () => {
  const addNotification = useStore((state) => state.addNotification);

  return (
    <div>
      <h1>DesignHub Dashboard</h1>
      
      {/* Simulation Buttons */}
      <div>
        <h3>Simulate Activity</h3>
        <button onClick={() => addNotification('New comment on file A')}>
          Rx Comment
        </button>
        <button onClick={() => addNotification('File B uploaded')}>
          Rx Upload
        </button>
      </div>

      <hr />
      
      <NotificationsPanel />
    </div>
  );
};

export default App;