import React from 'react';
import { useStore } from '../store/useStore';

export const NotificationsPanel: React.FC = () => {
  const notifications = useStore((state) => state.notifications);
  const markAsRead = useStore((state) => state.markAsRead);
  const clearNotifications = useStore((state) => state.clearNotifications);

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <div>
      <h2>Notifications Panel</h2>
      <p>Unread: {unreadCount}</p>

      {notifications.length > 0 && (
        <button onClick={clearNotifications}>Clear All</button>
      )}

      <ul>
        {notifications.map((note) => (
          <li key={note.id}>
            <span style={{ textDecoration: note.read ? 'line-through' : 'none' }}>
              {note.message}
            </span>
            
            {!note.read && (
              <button onClick={() => markAsRead(note.id)}>
                Mark Read
              </button>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
};